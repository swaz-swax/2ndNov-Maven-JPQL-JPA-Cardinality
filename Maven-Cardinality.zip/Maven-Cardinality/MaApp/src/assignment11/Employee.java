package assignment11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

class Employee 
{
	String name;
	double salary;
	Integer id;
	String designation;
	public String insuranceScheme;

	public Employee(String name, double salary, Integer id, String Designation) 
	{
		this.name = name;
		this.salary = salary;
		this.id = id;
		this.designation = Designation;
		insuranceScheme = getInsuranceScheme(salary);
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public double getSalary() 
	{
		return salary;
	}

	public void setSalary(double salary) 
	{
		this.salary = salary;
	}

	public Integer getId() 
	{
		return id;
	}

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public String getDesignation() 
	{
		return designation;
	}

	public void setDesignation(String designation) 
	{
		designation = designation;
	}

	public String getInsuranceScheme() 
	{
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) 
	{
		insuranceScheme = insuranceScheme;
	}

	public String getInsuranceScheme(double salary) 
	{
		
		if (salary > 5000 && salary < 20000) 
		{
			insuranceScheme = "scheme c";
		} 
		
		else if (salary >= 20000 && salary < 40000) 
		{
			insuranceScheme = "scheme b";
		} 
		
		else if (salary >= 40000) 
		{
			insuranceScheme = "scheme a";
		}
		
		else 
		{
			insuranceScheme = "null";
			
		}
		return insuranceScheme;
	}

	public String toString() {
		return "Name: " + name + " Id: " + id + " Salary: " + salary
				+ " Designation: " + designation + " InsuranceScheme: "
				+ insuranceScheme;
	}
}

class EmployeeServiceImpl {

	Employee e = new Employee("shravya", 12000, 1, "Clerk");
	HashMap<Integer, Employee> employeeMap;

	public void addEmployee(Employee emp) 
	{
		employeeMap.put(emp.id, emp);
	}

	public boolean deleteEmployee(int id) 
	{
		if (id == e.id)
		{
			employeeMap.remove(e);
			return true;
		}
		else
			return false;
	}

	public String ShowEmpDetails(String InsuranceScheme) 
	{
		String s = null;
		if (InsuranceScheme == "scheme a") 
		{
			s = "Name: " + e.name + " Id: " + e.id + " Salary: " + e.salary
					+ " Designation: " + e.designation + "InsuranceScheme: "
					+ e.insuranceScheme;

		} 
		
		else if (InsuranceScheme == "scheme b") 
		{
			s = "Name: " + e.name + " Id: " + e.id + " Salary: " + e.salary
					+ " Designation: " + e.designation + "InsuranceScheme: "
					+ e.insuranceScheme;
		}
		
		else if (InsuranceScheme == "scheme b") 
		{
			s = "Name: " + e.name + " Id: " + e.id + " Salary: " + e.salary
					+ " Designation: " + e.designation;
		} 
		else
			s = "null";
		return s;		
	}

	public void writeEmployeeToFile(Employee employee) throws IOException 
	{
		File f = new File("EmployeeDetails.txt");
		FileWriter fs = new FileWriter(f);
		fs.write(employee.toString());		
	}
}
