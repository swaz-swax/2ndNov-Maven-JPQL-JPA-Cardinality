package assignment10;

import java.io.*;
import java.util.*;
public class Source {
    
    public static void main(String[] args) throws Exception {
        
File file =  new File("numbers.txt"); 
        FileOutputStream fos=new FileOutputStream("result.txt");
                Scanner sc = new Scanner(file); 
                String s=sc.nextLine();
                char[] c=s.toCharArray();
                
                
                //int l=c.length;
                for(char a:c){
                if(a !=','){
                    int k=(int)a;
                    if(k%2==0){
                        fos.write(k);
                        fos.write(13);
                    }
                    
                }
                
                }
                fos.close();

    }
    }
         