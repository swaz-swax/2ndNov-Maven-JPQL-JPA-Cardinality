


		public class TestExcep2 {

			public static void main(String[] args) 
			{
				try{
				int finalRes=disp();
				//System.out.println("final result "+finalRes);
				}
				catch(Exception e){
					e.getMessage();
				}
				
			}

			private static int divide() throws ArithmeticException{
				int a=90;
				int c=a/0;
				return c;
			}

			private static int add() {
				int result=divide();
				return result;
			}

			private static int disp() {
			int res=add();	
			return res;
					
			}

		} 
		 

