package assignment13;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

// Class name should be "Source",
// otherwise solution won't be accepted
public class Source {
    // static String s1;
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
       String s="";
       String s11="";
        // Declare the variable
       s=in.next(); 
       s11=in.next();

    Person p=new Person(s);
    p.printName();
    Person p1=new Person(s11);
    p1.printName(); 

     //  List<String> l=new ArrayList<>();
   }
   
}
class Person extends Source{
     private String name;
    
     public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        Person(){}
        Person(String s1){
            setName(s1);
        }

    
    public void printName() {
        System.out.println(getName());
        
    }
    
}