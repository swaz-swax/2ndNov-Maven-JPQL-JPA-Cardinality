package assignment12;

import java.util.*;
import java.util.function.BiFunction;

public class Source 
{
    public static void main(String[] args) 
    {
    	Scanner in = new Scanner(System.in);
        
        String username=in.nextLine();
        String pwd=in.nextLine();

        BiFunction<String, String, Boolean> validate=(u,p)->
        {     
        Boolean s=true;
        if(username.equals("admin") && pwd.equals("admin"))
        {
        	s=true;
        }   
        else 
        {
        	s=false;    
        }
        return s;
        
        };
        System.out.println(validate.apply(username,pwd));
       in.close();
   }
}