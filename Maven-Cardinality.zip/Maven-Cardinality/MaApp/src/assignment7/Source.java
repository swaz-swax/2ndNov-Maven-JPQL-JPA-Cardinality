package assignment7;

import java.util.HashMap;

public class Source {
	
	
	static HashMap<Integer, Integer> getSquares(int []numbers)
	{ 
		HashMap<Integer, Integer> hashMap=new HashMap<Integer, Integer>();
		for(int i:numbers)
		{
			hashMap.put( i , i*i );
		}
		
		return hashMap;
	}

	public static void main(String[] args) 
	{
		int []numbers={1,2,3,4,5,6,7,8,9};
		System.out.println(getSquares(numbers));

	}

}
//collabedit.com/sfrvj