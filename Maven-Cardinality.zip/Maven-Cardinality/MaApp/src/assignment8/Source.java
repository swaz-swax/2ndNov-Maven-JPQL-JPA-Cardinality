package assignment8;

import java.util.Scanner;

public class Source 
{
	static Object lock=new Object();
	
	static int inputNumber;
	
	public static int getInputNumber() 
	{
		return inputNumber;
	}
	
	public static void setInputNumber(int i) 
	{
		Source.inputNumber = i;
	}

	public static void main(String[] args) 
	{
		
		Thread t1=new Thread(new Runnable() 
		{
			@Override
			public void run() 
			{
				synchronized (lock) 
				{
					Scanner scanner=new Scanner(System.in);
					int temp=scanner.nextInt();
					scanner.close();
					setInputNumber(temp);
				}	
			}
		});
		
		Thread t2=new Thread(new Runnable() 
		{	
			@Override
			public void run() 
			{
				synchronized (lock) 
				{
					int a=getInputNumber();
					int factorial=1;
					
					for(inputNumber=2;inputNumber<=a;inputNumber++)
					{
						factorial*=inputNumber;
					}
					
					System.out.println(factorial);
				}				
			}			
		});
		
		try 
			{
				t1.start();
				t2.start();
				t1.join();
				t2.join();
			} 
		catch (InterruptedException e) 
			{
				e.printStackTrace();
			}		
	}
}
