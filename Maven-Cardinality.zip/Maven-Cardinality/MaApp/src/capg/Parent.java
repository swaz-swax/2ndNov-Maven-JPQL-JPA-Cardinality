package capg;

public class Parent {
	int i=2;
	String s="Hello";
    public void p1(){ 
    	System.out.println("Parent class method p1()");
    }
}
