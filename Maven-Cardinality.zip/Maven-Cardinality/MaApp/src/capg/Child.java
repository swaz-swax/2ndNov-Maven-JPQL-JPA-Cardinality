package capg;

public class Child extends Parent {
  int c=1;
  String s="Child";
	public static void main(String[] args) {
		Parent p=new Parent();
	    System.out.println(p.i);
	    System.out.println(p.s);
	    p.p1();
	    Child c= new Child();
	    System.out.println(c.c);
	    System.out.println(c.s);
	    
	    
	    for (int i = 0; i < 4; i++) {
	    	double a=Math.random()*Math.pow(10,11);
	    	long ac1=(long) a;
		    System.out.println(ac1);
		}
	    
		
	    
	    Parent p1=new Child();
	    Child c1=(Child) new Parent();

	}

}
