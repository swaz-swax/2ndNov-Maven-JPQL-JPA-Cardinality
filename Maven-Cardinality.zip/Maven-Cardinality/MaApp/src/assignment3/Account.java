package assignment3;


public class Account {
	double balance;
	boolean withdraw(double bal){
		this.balance = this.balance - bal;		
		return true;
		
	}
	
	public static void main(String[] args) {
		
		 Account a= new SavingsAccount(900);
	        boolean saving = a.withdraw(300);
	        System.out.println(saving);
	        
	        	 a= new CurrentAccount(-5000);
	        boolean current = a.withdraw(300);
	        System.out.println(current);
	}
}

class SavingsAccount extends Account{
	 final float minBalance=500;
	 
	    public SavingsAccount(double balance)
	    {
	        this.balance = balance;
	    }
	    boolean withdraw(double bal){
	        if(this.balance-bal > minBalance){
	            this.balance = this.balance - bal;
	          
	            return true;
	        }
	        else
	            return false;
	    }
	}

class CurrentAccount extends Account{
	 final float overDraftLimit = -2000;
	 
	 public CurrentAccount(double balance)
	    {
	        this.balance = balance;
	    }

	 boolean withdraw(double bal){
	        if(this.balance-bal > overDraftLimit){
	            this.balance = this.balance - bal;
	            return true;
	        }
	        else
	            return false;
	    }
}