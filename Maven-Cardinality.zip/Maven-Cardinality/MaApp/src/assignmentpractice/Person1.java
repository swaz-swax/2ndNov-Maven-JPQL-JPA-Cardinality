package assignmentpractice;


import java.math.BigInteger;

class Person1{
    enum Gender{ M,F ;}
    Gender gender;
    String firstName,lastName;
    BigInteger number;
    public Person1 (){}
    public Person1(String firstName, String lastName,Gender gender,BigInteger number){
   /* this.firstName=firstName;
    this.lastName=lastName;
    this.gender=gender;
    this.number=number;*/
    	setFirstName(firstName);
    	setLastName(lastName);
    	setGender(gender);
    	setNumber(number);
    	
    
    }
    public void setFirstName(String firstName)
    {
        this.firstName=firstName;
    }
    public String getFirstName()
    {
        return this.firstName;
    }
    
    public void setLastName(String lastName)
    {
        this.lastName=lastName;
    }
    public String getLastName()
    {
        return this.lastName;
    }
    
    public void setGender(Gender gender)
    {
        this.gender=gender;
    }
    public Gender getGender()
    {
        return this.gender;
    }
    
    public void setNumber(BigInteger number)
    {
        this.number=number;
    }
    public BigInteger getNumber()
    {
        return this.number;
    }
    
    public String displayDetails(Person1 p)
    {
        String result="";
        
        result += "FirstName" + ": "+p.getFirstName() +"\n";
        result += "LastName" + ": "+ p.getLastName()+"\n";
        result += "Gender" + ": "+p.getGender() +"\n";
        result += "Number" + ": "+ p.getNumber()+"\n";
     
        return result;
    }
    public static void main(String[] args) {
        //Source s=new Source();
        Gender g1= Gender.F;
        Gender g2= Gender.M;
        BigInteger b= new BigInteger("9988888889");
        Person1 p=new Person1("CAP","GEMINI",g2,b);
        System.out.println(p.displayDetails(p));
    }
}
