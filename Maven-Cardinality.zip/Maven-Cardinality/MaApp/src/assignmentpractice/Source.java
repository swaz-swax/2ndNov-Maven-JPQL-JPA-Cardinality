package  assignmentpractice;

import java.util.Scanner;

class Source{
	public static void main(String[] args) {
		System.out.println("enter a no.:  ");
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		
		
	}
	
}