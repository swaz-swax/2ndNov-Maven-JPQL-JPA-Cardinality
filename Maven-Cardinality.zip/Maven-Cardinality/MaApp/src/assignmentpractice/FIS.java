package assignmentpractice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FIS {

	public static void main(String[] args) {
		//FileInputStream input=null;
		FileReader input=null;
		//FileWriter output=null;
		FileOutputStream output=null;
	
		try {	
				//input=new FileInputStream("input.txt"); // reporting exception by the compiler 
			input=new FileReader("input.txt"); // Reading the file
			//output=new FileWriter("output.txt");
			output=new FileOutputStream("output.txt");
			int n;
				while((n=input.read()) !=-1)
				{
					//System.out.print((char)n);
					//output.flush();
					output.write(n);  // writing to output file
					//output.append((char)n);
				}
			} 
		catch (FileNotFoundException e) 
			{		
				e.printStackTrace();
			} 
		catch (IOException e) {
			
				e.printStackTrace();
			}	
		finally{ 
			try {
			input.close();
		} catch (IOException e) {
			e.printStackTrace();
		} 
			}		
	}
}
