package assignmentpractice;

import java.math.BigInteger;




enum Gender{ M,F ;}
class Person{
    
    Gender gender;
    String firstName,lastName;
    BigInteger phoneNumber;
    public Person (){}
    public Person(String firstName, String lastName,Gender gender,BigInteger phoneNumber){
    this.firstName=firstName;
    this.lastName=lastName;
    this.gender=gender;
    this.phoneNumber=phoneNumber;
    
    }
    
    
    
   
	
    
    public String displayDetails(Person p)
    {
        String result="";
        
        result += "FIRSTNAME" + ": "+p.firstName +"\n";
        result += "LASTNAME" + ": "+ p.lastName+"\n";
        result += "GENDER" + ": "+p.gender +"\n";
        result += "NUMBER" + ": "+ p.phoneNumber+"\n";
     
        return result;
    }
    
    final public static void main(String[] args) {
        //Source s=new Source();
        Gender g1= Gender.F;
        Gender g2= Gender.M;
        BigInteger b= new BigInteger("9988888889");
        Person p=new Person("CAP","GEMINI",g2,b);
        System.out.println(p.displayDetails(p));
    }
}

