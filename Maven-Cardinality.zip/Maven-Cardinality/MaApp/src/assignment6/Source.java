package assignment6;

import java.util.ArrayList;
import java.util.List;

public class Source 
{

	static List<String> removeElements(List<String> l1,List<String> l2) 
	{
		l1.removeAll(l2);
		return l1;
	}
	
	
	public static void main(String[] args) 
	{
		List<String> list1 = new ArrayList<String>();
		list1.add("swarup");
		list1.add("talukdar");
		list1.add("ghi");
		list1.add("jkl");
		
		List<String> list2 = new ArrayList<String>();
		list2.add("ghi");
		list2.add("talukdar");
		System.out.println(removeElements(list1,list2));

	}

}


//collabedit.com/da9j6