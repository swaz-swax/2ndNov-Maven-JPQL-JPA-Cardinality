package assignment5;

abstract class Account {
    
        long accNum=123456789;
        double balance;
        private Person accHolder;
        
        
        Account()
        {
            
        } 
       Account(String name,float age,double balance)
        {
          Person accHolder=new Person();
          setAccHolder(accHolder);
          this.balance=balance;
          }
       
       public long getAccNum() {
           return accNum;
       }

       public void setAccNum(long accNum) {
           this.accNum = accNum;
       }
       
          public void setAccHolder(Person accHolder) {
            this.accHolder = accHolder;
        }

        public void deposit(double rupees) {
        
        this.balance=this.balance+rupees;
      }
abstract void withdraw(double rupees);
    
      public String toString() {
        
        return "Name: "+accHolder.getName()+" Age: "+accHolder.getAge()+" AccNumber: "+this.accNum+" Balance= "+this.balance;
      }

      public double getBalance() {
        
        return this.balance;
      }
      
      public void setBalance(double bal){
        	        if(bal>500)
        this.balance=bal;
      }  

      public void setAccountDetails(String name, int age, int balance) {
        
        accHolder.setName(name);
        accHolder.setAge(age);
        this.balance=balance;
      }
      
      public Person getPerson(){
        
        return accHolder;
      }

}
