package assignment5;


class Person extends Account {
    private String name;
    private float age;
   
    Person()
    {
          
        
    }
    Person(String name,float age,double bal)
    {
        super(name,age,bal);
        this.name=name;
        this.age=age;
  
       
    }

public Person(String name2, float age2) {
        
    this.name=name2;
    this.age=age2;
    }
   public String getName() {
	    return name;
	  }
public void setName(String name) {
    this.name = name;
  }

public float getAge() {
    return age;
  }

public void setAge(float age) {
    this.age = age;
    
  }


    public static void main(String[] args) {
        
          Account a=new Person("xyz",1653,1000);
         
        
          a.setBalance(1000);
          a.accNum=123456789;
          a.withdraw(100);
          System.out.println(a);


    }
    
    void withdraw(double rupees) {
       
        if(getBalance()-rupees>=500)
           {
               setBalance(getBalance()-rupees);
           }
        
    }
 }


//2fmcg
