import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class KeyBoardReader {

	public static void main(String[] args) {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		//int n;
		String s;
		try {
			//n = br.read();
			System.out.println("Enter ur text: ");
			while(!(s = br.readLine()).equals("exit")){		
			System.out.println("Entered text: "+ s);}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}

}
