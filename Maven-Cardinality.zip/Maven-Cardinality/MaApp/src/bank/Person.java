package bank;

public class Person {
	private String name;
	private float age;
	
	public String getName() {
		return name;
	}
	Person(){}
	
	Person(String name, float age){
		this.name=name;
		this.age=age;
		
	}
	 
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}

}
