package bank;



public class Account extends Person {
	public static long accNum=12233;
	public double balance;

	public long getAccNum() {
		return accNum;
	}
	
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	
	 private Person accHolder=new Person();
	 
	Account(String name, float age, double balance){
		this.balance=balance;
		getPerson().setAge(age);
		getPerson().setName(name);
	}

	public void deposit(double rupees)
	{this.balance+=rupees;
	}
	
	public void withdraw(double rupees){
		this.balance-=rupees;
	}
	
	public String toString()
	{
		return "\nName: "+accHolder.getName()+ "\nAge: "+ accHolder.getAge() +"\nAccount Number: "+this.accNum + "\nBalance: "+this.balance;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public void setBalance(double balance) {
		if(balance>500)
		{
		this.balance = balance;}
	}
	
	public void setAccountDetails(String name, float age, double balance) {
		accHolder.setName(name);
		accHolder.setAge(age);
		this.balance=balance;
	}

	public Person getPerson() {
		return accHolder;
	}
	public static void main(String[] args){
		
		Account a=new Account("ABC",12,3000);
		System.out.println(a);
	}
	
}
