import java.util.Scanner;

public class D {
	public static void main(String[] args) {
		/*
		 * String s4="12.3.3.3"; Scanner sc=new Scanner(s4).useDelimiter("\\.");
		 */
		/*
		 * while(sc.hasNext()) { String data=sc.next();
		 * System.out.println(data); }
		 */
		// String s4="12.3.3.3";
		// String a[]=s4.split(".");
int c=0;
		Scanner sc1 = new Scanner(System.in);
		System.out.println("enter ip:");
		String ip = sc1.nextLine();
		Scanner sc = new Scanner(ip).useDelimiter("\\.");

		while (sc.hasNext()) {
			String b = sc.next();
			int a = Integer.valueOf(b);
			boolean flag = false;
			if (a >= 0 && a <= 255) {
				flag = true;
			}
			/*System.out.println(a + " " + flag);*/
			if (flag == false) {
				 c++;
				break;}
			}
		if(c==0){
			System.out.println("valid id");
		}
		sc1.close();
		sc.close();
	}

}
