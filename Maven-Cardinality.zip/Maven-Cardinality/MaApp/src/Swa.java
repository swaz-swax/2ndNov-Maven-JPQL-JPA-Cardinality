
public class Swa 
{

	public static void main(String[] args) 
	{
		int a=10;
		int b=0;
		int c;
		try{
		c=a/b;}
		catch(Exception e){
			e.getMessage();
		}
		
		System.out.println();
	}

}
