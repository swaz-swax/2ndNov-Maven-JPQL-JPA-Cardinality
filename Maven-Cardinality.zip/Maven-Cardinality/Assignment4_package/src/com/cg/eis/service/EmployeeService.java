package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	int schemeCBal=1000;
	int schemeBBal=5000;
	int schemeABal=15000;
	
	
	
	public int maxMedicalInsurance(Employee e1);
	

}
