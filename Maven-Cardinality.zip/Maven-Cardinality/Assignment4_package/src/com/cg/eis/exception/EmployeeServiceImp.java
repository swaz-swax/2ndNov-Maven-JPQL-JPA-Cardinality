package com.cg.eis.exception;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class EmployeeServiceImp implements EmployeeService {

	@Override
	public int maxMedicalInsurance(Employee e) {
		String s=e.insuranceScheme;
		
		if(s == "scheme c")
			{
			return schemeCBal;
			}
		if(s == "scheme b")
			{
			return schemeBBal;
			}
		if(s == "scheme a")
			{
			return schemeABal;
			}
		else
			{
			return 0;
			}
		
	
	}

}
