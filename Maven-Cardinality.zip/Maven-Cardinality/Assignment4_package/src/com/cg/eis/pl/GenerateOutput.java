package com.cg.eis.pl;



import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeServiceImp;


public class GenerateOutput {

	public static void main(String[] args) {
		double sal=30000;
		Employee e = new Employee(4544,"swarup", sal,"Programmer");
		System.out.println(e.getInsuranceScheme(sal));
		EmployeeServiceImp service=new EmployeeServiceImp();
		System.out.println(service.maxMedicalInsurance(e));
		
		
		
	}

}

//collabedit.com/xdd3e